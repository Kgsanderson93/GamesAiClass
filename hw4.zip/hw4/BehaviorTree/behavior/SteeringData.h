#pragma once
#include <SFML/Graphics.hpp>
#include "../World/gameTile.h"
#include <vector>

      
class SteeringData{

    public:
        sf::Vector2f linear;
        float angular;

};