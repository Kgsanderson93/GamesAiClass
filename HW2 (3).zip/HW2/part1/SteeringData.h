#pragma once
#include <SFML/Graphics.hpp>

      
class SteeringData{

    public:
        sf::Vector2f linear;
        float angular;

};